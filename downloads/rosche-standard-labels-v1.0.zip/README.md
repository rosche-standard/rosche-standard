# Rosche Standard – Label-Set v1.0

Enthalten:
- SVG & PNG (600×600 px) der drei Stufen
  - Grün – KI-assistiert (KI.svg/png)
  - Gelb – Ko-verfasst (KO.svg/png)
  - Rot – Generiert-redigiert (GR.svg/png)

## Nutzung
1. Level wählen
2. Label im Layout platzieren (z. B. unten rechts)
3. „Nach Rosche Standard (CC BY 4.0)“ ergänzen
